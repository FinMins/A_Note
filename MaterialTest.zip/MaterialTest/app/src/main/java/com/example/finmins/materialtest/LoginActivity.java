package com.example.finmins.materialtest;


import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LoginActivity extends AppCompatActivity  {
    private static  final  String TAV = "LoginActivity.this";
    private EditText userName;      //输入用户名的空控件
    private EditText userPassword;   // 输入密码的空间
    private  String userName_String;  // 用户名
    private String userPassword_String;  //用户密码
    private Button loginIn ;  //登录按钮
    private Button register;    //注册按钮

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
     init();

        //登录按钮功能
        loginIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //获得输入的账号密码
                //账号密码进行匹配
                //如果正确则登录成功，进入个人账户界面;

                Toast.makeText(LoginActivity.this,"登录按钮",Toast.LENGTH_SHORT).show();
            }
        });

        //注册按钮功能
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //进入注册界面
                Toast.makeText(LoginActivity.this,"注册按钮",Toast.LENGTH_SHORT).show();
            }
        });

    }


    //加载插件
    private void init(){
        userName = (EditText)findViewById(R.id.userName);
        userPassword = (EditText)findViewById(R.id.userPassword);
        loginIn = (Button)findViewById(R.id.login);
        register = (Button)findViewById(R.id.register);
    }

    //获取用户输入的信息
    private void getInformation(){
        userName_String = userName.getText().toString().trim();    //获取用户输入的账号，并去掉空隔。
        userPassword_String=userPassword.getText().toString().trim();  //获取用户输入的密码，并去掉空隔。
    }
     //检查账号与密码是否匹配，是返回1，否返回0
    private int checkInformation(String name,String password ){



        return 0;
    }




}

