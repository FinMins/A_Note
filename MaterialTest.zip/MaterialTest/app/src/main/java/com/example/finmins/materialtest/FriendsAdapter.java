package com.example.finmins.materialtest;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;

/**
 * Created by FinMins on 2020/4/13.
 */

public class FriendsAdapter extends  RecyclerView.Adapter<FriendsAdapter.ViewHolder>{
    private List<Friend> mFriendList;


    public class ViewHolder extends  RecyclerView.ViewHolder{
        View friendView;
       ImageButton friend_image;
        TextView friend_name;

        public ViewHolder(View view){
        super(view);
    friendView = view;
            friend_image = (ImageButton)view.findViewById(R.id.friend_image);
            friend_name = (TextView)view .findViewById(R.id.friend_name);
        }
    }

    public FriendsAdapter(List<Friend> friendList){
        mFriendList = friendList ;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.friend_item,parent,false);
        final  ViewHolder holder = new ViewHolder(view);
        holder.friendView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                int position = holder.getAdapterPosition();
                Friend friend = mFriendList.get(position);
                //点击每一个朋友执行的逻辑
                Toast.makeText(v.getContext(),"asd"+friend.getFriendName(),Toast.LENGTH_SHORT).show();
            }
        });






        return holder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Friend friend = mFriendList.get(position);
        holder.friend_image.setImageResource( friend.getFriendImage());
        holder.friend_name.setText(friend.getFriendName());
    }

    @Override
    public int getItemCount() {
        return mFriendList.size();
    }
}