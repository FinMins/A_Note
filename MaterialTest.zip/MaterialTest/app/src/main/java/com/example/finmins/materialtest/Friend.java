package com.example.finmins.materialtest;

import android.widget.ImageButton;

/**
 * Created by FinMins on 2020/4/13.
 */

public class Friend {
    private int friendImage;   //好友头像
    private String friendName;  //好友名字


    public void Friend(int friendImage, String friendName) {
        this.friendImage = friendImage;
        this.friendName = friendName;
    }

    public String getFriendName(){
        return  friendName;}
     public int getFriendImage(){
         return  friendImage;
     }
}

